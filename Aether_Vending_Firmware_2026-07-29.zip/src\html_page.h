// Auto-generated mobile web page header
#pragma once
#include <Arduino.h>

const char html_page[] PROGMEM = R"rawhtml(
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Aether Cloud Controller | Vending Machine #5552</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/paho-mqtt/1.0.1/mqttws31.min.js"></script>
    <style>
/* AETHER CONTROLLER - MOBILE-FIRST STYLESHEET */
:root {
    --bg-gradient: linear-gradient(145deg, #070a14 0%, #0d1322 40%, #15102a 100%);
    --card-bg: rgba(22, 28, 45, 0.65);
    --card-border: rgba(255, 255, 255, 0.08);
    --accent-cyan: #00f2fe;
    --accent-blue: #4facfe;
    --accent-purple: #9d4edd;
    --accent-gold: #ffb703;
    --accent-red: #ff0055;
    --text-primary: #f8fafc;
    --text-secondary: #94a3b8;
    --text-muted: #64748b;
    --success: #10b981;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;
    user-select: none;
}

body {
    font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg-gradient);
    color: var(--text-primary);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding: 16px 12px;
    overflow-x: hidden;
}

.app-container {
    width: 100%;
    max-width: 500px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

/* HEADER */
.app-header {
    background: rgba(15, 23, 42, 0.75);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid var(--card-border);
    border-radius: 20px;
    padding: 18px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
}

.brand-title {
    font-size: 24px;
    font-weight: 800;
    letter-spacing: 2px;
    background: linear-gradient(135deg, var(--accent-cyan), var(--accent-purple));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.brand-subtitle {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 1px;
    color: var(--text-secondary);
    margin-top: 2px;
}

.status-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(16, 185, 129, 0.12);
    border: 1px solid rgba(16, 185, 129, 0.3);
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    color: var(--success);
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
}

.status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--success);
    box-shadow: 0 0 10px var(--success);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(0.85); }
}

/* CARDS */
.card {
    background: var(--card-bg);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid var(--card-border);
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.25);
}

.card-title {
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: var(--text-secondary);
    margin-bottom: 14px;
}

.card-header-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 14px;
}

.card-header-row .card-title {
    margin-bottom: 0;
}

/* IP CONNECTION CARD */
.ip-card {
    padding: 16px 20px;
}

.ip-mode-badge {
    font-size: 10px;
    font-family: 'JetBrains Mono', monospace;
    font-weight: 700;
    color: var(--accent-cyan);
    background: rgba(0, 242, 254, 0.1);
    border: 1px solid rgba(0, 242, 254, 0.2);
    padding: 3px 8px;
    border-radius: 10px;
}

.ip-input-row {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.ip-input {
    flex: 1;
    background: rgba(15, 23, 42, 0.7);
    border: 1px solid var(--card-border);
    border-radius: 12px;
    padding: 10px 14px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 13px;
    color: var(--text-primary);
    outline: none;
    user-select: text;
    transition: border-color 0.2s ease;
}

.ip-input:focus {
    border-color: var(--accent-cyan);
}

.btn-connect-ip {
    background: rgba(0, 242, 254, 0.15);
    border: 1px solid var(--accent-cyan);
    color: var(--accent-cyan);
    padding: 10px 16px;
    font-size: 12px;
}

.btn-connect-ip:hover {
    background: var(--accent-cyan);
    color: #050b14;
}

.ip-hint {
    font-size: 11px;
    color: var(--text-muted);
    margin-top: 8px;
}

.ip-hint strong {
    color: var(--text-secondary);
}

/* TELEMETRY GRID */
.telemetry-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
}

.telemetry-box {
    background: rgba(15, 23, 42, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 14px;
    padding: 12px 8px;
    text-align: center;
}

.box-label {
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--text-muted);
    display: block;
    margin-bottom: 6px;
}

.box-value {
    font-family: 'JetBrains Mono', monospace;
    font-size: 15px;
    font-weight: 700;
    color: var(--accent-cyan);
}

.state-value {
    color: var(--accent-gold);
}

/* SLIDER CONTROL */
.slider-readout {
    font-family: 'JetBrains Mono', monospace;
    font-size: 20px;
    font-weight: 800;
    color: var(--accent-cyan);
    text-shadow: 0 0 12px rgba(0, 242, 254, 0.35);
}

.slider-wrapper {
    margin: 10px 0 20px 0;
}

.custom-slider {
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
    height: 12px;
    border-radius: 6px;
    background: rgba(30, 41, 59, 0.8);
    outline: none;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.4);
}

.custom-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent-cyan), var(--accent-blue));
    cursor: pointer;
    box-shadow: 0 0 16px var(--accent-cyan), 0 4px 10px rgba(0, 0, 0, 0.4);
    border: 2px solid #ffffff;
    transition: transform 0.15s ease;
}

.custom-slider::-webkit-slider-thumb:active {
    transform: scale(1.15);
}

.slider-ticks {
    display: flex;
    justify-content: space-between;
    margin-top: 8px;
    font-size: 10px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--text-muted);
}

/* BUTTONS */
.btn {
    border: none;
    outline: none;
    font-family: 'Outfit', sans-serif;
    font-weight: 700;
    border-radius: 14px;
    cursor: pointer;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.btn:active {
    transform: scale(0.96);
}

.preset-row {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 8px;
    margin-bottom: 16px;
}

.btn-preset {
    background: rgba(30, 41, 59, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.08);
    color: var(--text-secondary);
    padding: 10px 0;
    font-size: 12px;
    font-family: 'JetBrains Mono', monospace;
}

.btn-preset:hover, .btn-preset.active {
    background: rgba(0, 242, 254, 0.15);
    border-color: var(--accent-cyan);
    color: var(--accent-cyan);
}

.btn-primary {
    width: 100%;
    padding: 16px;
    font-size: 15px;
    letter-spacing: 1px;
    background: linear-gradient(135deg, var(--accent-cyan), var(--accent-blue));
    color: #050b14;
    box-shadow: 0 8px 24px rgba(0, 242, 254, 0.35);
}

.action-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 12px;
}

.btn-action {
    background: rgba(30, 41, 59, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.08);
    color: var(--text-primary);
    padding: 14px;
    font-size: 13px;
}

.btn-action:hover {
    border-color: var(--accent-purple);
    background: rgba(157, 78, 221, 0.15);
    color: #e0aaff;
}

.btn-danger {
    width: 100%;
    padding: 16px;
    font-size: 15px;
    letter-spacing: 1px;
    background: linear-gradient(135deg, #ff0055, #d90429);
    color: #ffffff;
    box-shadow: 0 8px 24px rgba(255, 0, 85, 0.4);
}

.btn-text {
    background: none;
    border: none;
    color: var(--text-muted);
    font-size: 11px;
    cursor: pointer;
}

/* TERMINAL */
.console-terminal {
    background: rgba(10, 15, 26, 0.85);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 12px;
    padding: 12px;
    height: 120px;
    overflow-y: auto;
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.log-line {
    display: flex;
    gap: 8px;
    line-height: 1.4;
}

.log-time {
    color: var(--text-muted);
    flex-shrink: 0;
}

.log-msg {
    color: var(--text-secondary);
}

.log-line.success .log-msg { color: var(--success); }
.log-line.error .log-msg { color: var(--accent-red); }
.log-line.cmd .log-msg { color: var(--accent-cyan); }

</style>
</head>
<body>
    <div class="app-container">
        <!-- HEADER -->
        <header class="app-header">
            <div class="brand-group">
                <h1 class="brand-title">AETHER</h1>
                <p class="brand-subtitle">ONLINE VENDING MACHINE #5552</p>
            </div>
            <div class="status-badge" id="netStatusBadge">
                <span class="status-dot"></span>
                <span id="netStatusText">CONNECTING CLOUD...</span>
            </div>
        </header>

        <!-- ONLINE MACHINE BROKER BAR -->
        <section class="card ip-card" id="ipCard">
            <div class="card-header-row">
                <h2 class="card-title">Cloud Target Settings</h2>
                <span class="ip-mode-badge" id="ipModeBadge">MACHINE #5552</span>
            </div>
            <div class="ip-input-row">
                <input type="text" id="machineIdInput" class="ip-input" value="5552" placeholder="Machine ID (e.g. 5552)">
                <button class="btn btn-connect-ip" id="btnConnectIp">CONNECT</button>
            </div>
            <p class="ip-hint">Cloud Relay: <strong>broker.hivemq.com (WSS)</strong> | Status: <span id="cloudRelayStatus">Active</span></p>
        </section>

        <!-- LIVE TELEMETRY DASHBOARD -->
        <section class="card telemetry-card">
            <h2 class="card-title">Live System Telemetry</h2>
            <div class="telemetry-grid">
                <div class="telemetry-box">
                    <span class="box-label">Motor State</span>
                    <span class="box-value state-value" id="telemetryStatus">CONNECTING</span>
                </div>
                <div class="telemetry-box">
                    <span class="box-label">Position</span>
                    <span class="box-value" id="telemetryMm">0.0 mm</span>
                </div>
                <div class="telemetry-box">
                    <span class="box-label">Step Count</span>
                    <span class="box-value" id="telemetrySteps">0 / 3200</span>
                </div>
            </div>
        </section>

        <!-- POSITION SLIDER CONTROL -->
        <section class="card control-card">
            <div class="card-header-row">
                <h2 class="card-title">Position Control</h2>
                <span class="slider-readout" id="sliderValue">0.0 mm</span>
            </div>
            
            <div class="slider-wrapper">
                <input type="range" id="posSlider" min="0" max="80" value="0" step="1" class="custom-slider">
                <div class="slider-ticks">
                    <span>0mm</span>
                    <span>20mm</span>
                    <span>40mm</span>
                    <span>60mm</span>
                    <span>80mm</span>
                </div>
            </div>

            <!-- PRESET QUICK BUTTONS -->
            <div class="preset-row">
                <button class="btn btn-preset" data-val="0">0mm</button>
                <button class="btn btn-preset" data-val="20">20mm</button>
                <button class="btn btn-preset" data-val="40">40mm</button>
                <button class="btn btn-preset" data-val="60">60mm</button>
                <button class="btn btn-preset" data-val="80">80mm</button>
            </div>

            <button class="btn btn-primary btn-action-main" id="btnGo">DISPENSE / MOVE POSITION</button>
        </section>

        <!-- QUICK MACRO ACTIONS -->
        <section class="card actions-card">
            <h2 class="card-title">System Commands</h2>
            <div class="action-grid">
                <button class="btn btn-action" id="btnHome">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                    <span>Calibrate (Home)</span>
                </button>
                <button class="btn btn-action" id="btnSweep">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
                    <span>Diagnostic Sweep</span>
                </button>
                <button class="btn btn-action" id="btnZeroStock" style="background: rgba(255, 183, 3, 0.15); border-color: rgba(255, 183, 3, 0.4); color: var(--accent-gold);">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M12 8v8M8 12h8"></path></svg>
                    <span>Set Zero Stock</span>
                </button>
            </div>
            <button class="btn btn-danger btn-stop" id="btnStop">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><rect x="9" y="9" width="6" height="6"></rect></svg>
                <span>EMERGENCY STOP</span>
            </button>
        </section>

        <!-- CONSOLE TERMINAL -->
        <section class="card console-card">
            <div class="card-header-row">
                <h2 class="card-title">Cloud Activity Log</h2>
                <button class="btn-text" id="btnClearLog">Clear</button>
            </div>
            <div class="console-terminal" id="sysConsole">
                <div class="log-line info">
                    <span class="log-time">[00:00:00]</span>
                    <span class="log-msg">Connecting to Aether Cloud Broker for Machine #5552...</span>
                </div>
            </div>
        </section>
    </div>

    <script>
// AETHER ONLINE MACHINE #5552 - CLOUD CLIENT LOGIC
document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const posSlider = document.getElementById('posSlider');
    const sliderValue = document.getElementById('sliderValue');
    const btnGo = document.getElementById('btnGo');
    const btnHome = document.getElementById('btnHome');
    const btnSweep = document.getElementById('btnSweep');
    const btnStop = document.getElementById('btnStop');
    const btnClearLog = document.getElementById('btnClearLog');
    
    const machineIdInput = document.getElementById('machineIdInput');
    const btnConnectIp = document.getElementById('btnConnectIp');
    const ipModeBadge = document.getElementById('ipModeBadge');
    const cloudRelayStatus = document.getElementById('cloudRelayStatus');

    const telemetryStatus = document.getElementById('telemetryStatus');
    const telemetryMm = document.getElementById('telemetryMm');
    const telemetrySteps = document.getElementById('telemetrySteps');
    const netStatusBadge = document.getElementById('netStatusBadge');
    const netStatusText = document.getElementById('netStatusText');
    const sysConsole = document.getElementById('sysConsole');

    const presetButtons = document.querySelectorAll('.btn-preset');

    // Parse machine ID from URL query parameter if present
    const urlParams = new URLSearchParams(window.location.search);
    const urlId = urlParams.get('id');
    if (urlId) {
        localStorage.setItem('aether_machine_id', urlId);
    }
    let machineId = urlId || localStorage.getItem('aether_machine_id') || '5552';
    machineIdInput.value = machineId;

    // MQTT Variables
    let mqttClient = null;
    let isConnectedMqtt = false;

    // Connect to HiveMQ Public WSS Broker
    function connectMqtt() {
        const clientId = 'aether_web_' + Math.random().toString(16).substr(2, 8);
        const host = 'broker.hivemq.com';
        const port = 8884; // WSS SSL port

        logConsole(`Connecting to Cloud MQTT Broker (wss://${host}:${port})...`, 'info');
        netStatusText.textContent = 'CONNECTING...';

        try {
            mqttClient = new Paho.MQTT.Client(host, port, clientId);

            mqttClient.onConnectionLost = onConnectionLost;
            mqttClient.onMessageArrived = onMessageArrived;

            mqttClient.connect({
                useSSL: true,
                timeout: 5,
                keepAliveInterval: 30,
                onSuccess: onConnectSuccess,
                onFailure: onConnectFailure
            });
        } catch (e) {
            logConsole(`MQTT Init Error: ${e.message}. Falling back to HTTP.`, 'error');
            setupHttpFallback();
        }
    }

    function onConnectSuccess() {
        isConnectedMqtt = true;
        netStatusBadge.style.borderColor = 'rgba(16, 185, 129, 0.4)';
        netStatusText.textContent = `CLOUD #5552`;
        cloudRelayStatus.textContent = 'Connected (MQTT WSS)';
        cloudRelayStatus.style.color = 'var(--success)';
        ipModeBadge.textContent = `MACHINE #${machineId}`;

        const statusTopic = `aether/vending/${machineId}/status`;
        mqttClient.subscribe(statusTopic);
        logConsole(`Cloud MQTT Connected! Subscribed to topic: ${statusTopic}`, 'success');

        // Request current status
        sendMqttCommand('STATUS');
    }

    function onConnectFailure(response) {
        isConnectedMqtt = false;
        logConsole(`Cloud MQTT Connection Failed (${response.errorMessage}). Retrying...`, 'error');
        netStatusBadge.style.borderColor = 'rgba(255, 183, 3, 0.4)';
        netStatusText.textContent = 'CLOUD RETRY';
        cloudRelayStatus.textContent = 'Disconnected';
        cloudRelayStatus.style.color = 'var(--accent-red)';
        setTimeout(connectMqtt, 5000);
    }

    function onConnectionLost(responseObject) {
        isConnectedMqtt = false;
        if (responseObject.errorCode !== 0) {
            logConsole(`Cloud MQTT Connection Lost: ${responseObject.errorMessage}`, 'error');
        }
        netStatusBadge.style.borderColor = 'rgba(239, 68, 68, 0.4)';
        netStatusText.textContent = 'RECONNECTING...';
        cloudRelayStatus.textContent = 'Lost Connection';
        setTimeout(connectMqtt, 3000);
    }

    function onMessageArrived(message) {
        try {
            const data = JSON.parse(message.payloadString);
            telemetryStatus.textContent = data.status.toUpperCase();
            telemetryMm.textContent = `${parseFloat(data.mm).toFixed(1)} mm`;
            telemetrySteps.textContent = `${data.pos} / 3200`;

            if (data.status === 'moving' || data.status === 'sweeping') {
                telemetryStatus.style.color = 'var(--accent-gold)';
            } else if (data.status === 'idle') {
                telemetryStatus.style.color = 'var(--success)';
            } else {
                telemetryStatus.style.color = 'var(--accent-cyan)';
            }
        } catch (e) {
            logConsole(`Raw Message: ${message.payloadString}`, 'info');
        }
    }

    function sendMqttCommand(cmdStr) {
        if (!isConnectedMqtt || !mqttClient) {
            logConsole('MQTT not connected yet, command queued.', 'error');
            return;
        }
        const cmdTopic = `aether/vending/${machineId}/cmd`;
        const message = new Paho.MQTT.Message(cmdStr);
        message.destinationName = cmdTopic;
        mqttClient.send(message);
        logConsole(`Published MQTT -> [${cmdTopic}]: ${cmdStr}`, 'cmd');
    }

    // Machine ID Switcher
    btnConnectIp.addEventListener('click', () => {
        let val = machineIdInput.value.trim();
        if (!val) return;
        machineId = val;
        localStorage.setItem('aether_machine_id', machineId);
        ipModeBadge.textContent = `MACHINE #${machineId}`;
        logConsole(`Switched active Cloud Target to Machine #${machineId}`, 'info');
        if (mqttClient && mqttClient.isConnected()) {
            mqttClient.disconnect();
        }
        connectMqtt();
    });

    // Slider Drag Readout
    posSlider.addEventListener('input', (e) => {
        sliderValue.textContent = `${parseFloat(e.target.value).toFixed(1)} mm`;
        updatePresetActiveState(e.target.value);
    });

    // Preset Button Click Handlers
    presetButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const val = btn.getAttribute('data-val');
            posSlider.value = val;
            sliderValue.textContent = `${parseFloat(val).toFixed(1)} mm`;
            updatePresetActiveState(val);
            sendMqttCommand(`GO:${val}`);
        });
    });

    function updatePresetActiveState(val) {
        presetButtons.forEach(b => {
            if (b.getAttribute('data-val') === String(val)) {
                b.classList.add('active');
            } else {
                b.classList.remove('active');
            }
        });
    }

    // Action Handlers
    btnGo.addEventListener('click', () => {
        sendMqttCommand(`GO:${posSlider.value}`);
    });

    btnHome.addEventListener('click', () => {
        sendMqttCommand('HOME');
    });

    btnSweep.addEventListener('click', () => {
        sendMqttCommand('SWEEP');
    });

    const btnZeroStock = document.getElementById('btnZeroStock');
    if (btnZeroStock) {
        btnZeroStock.addEventListener('click', () => {
            sendMqttCommand('ZERO_STOCK');
            fetch('/api/calibrate_zero').then(r => r.json()).then(data => {
                logConsole(`Zero Stock Calibration Complete! Limit set to ${data.empty_depth_mm} mm`, 'success');
            }).catch(e => {
                logConsole('Calibrated Zero Stock via Cloud Command.', 'info');
            });
        });
    }

    btnStop.addEventListener('click', () => {
        sendMqttCommand('STOP');
    });

    btnClearLog.addEventListener('click', () => {
        sysConsole.innerHTML = '';
        logConsole('Console cleared.', 'info');
    });

    // Console Logging Helper
    function logConsole(msg, level = 'info') {
        const now = new Date();
        const timeStr = now.toTimeString().split(' ')[0];
        
        const line = document.createElement('div');
        line.className = `log-line ${level}`;
        line.innerHTML = `<span class="log-time">[${timeStr}]</span><span class="log-msg">${msg}</span>`;
        
        sysConsole.appendChild(line);
        sysConsole.scrollTop = sysConsole.scrollHeight;
    }

    // Initialize MQTT Connection
    connectMqtt();
});

</script>
</body>
</html>

)rawhtml";
